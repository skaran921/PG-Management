<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Other Expenses - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/feeReceived.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
           <div class="card" style="width:40%;margin:auto;">
                  <div class="card-header" style="background-color:#4834DF !important">
                        <span class="fas fa-rupee-sign"></span> Other Expenses
                  </div>
                  <!-- card-header -->
                  <div class="card-body"> 
                         <form action="" method="post">
                             <div class="form-group">
                                    <label> Select Date(M/D/Y):</label>
                                    <input type="date" name="expenses_date" id="expenses_date" required autofocus>                                   
                                   <label>Expenses Amount:</label>
                                   <input type="number" name="other_amount" id="other_amount" placeholder="Other Expenses Paid Amount" required> 
                                   <label>Narration:</label>
                                   <textarea name="narration" id="narraton" placeholder="write some note about expense eg. for fain repair" required></textarea>
                                   <button type="submit" style="background-color:#4834DF" name="save" class="button" >
                                    <span class="fas fa-rupee-sign"></span> Save Other Expenses</button>
                             </div>
                         </form>
                  </div>
                 <!-- card-body -->
           </div>
           <!-- card -->

           <!-- last record -->
               <div class="card" style="margin-top:10px;width:100%">
                     <div class="card-header" style="background-color:#2ecc71 !important">
                           <span class="fas fa-list-alt"></span> Last Entry Record
                     </div>
                     
                     <div class="card-body">
                         <div class="main_Table" style="overflow-x:auto">
                            <table  class="table table-bordered">                                
                                     <thead class="thead-light">
                                         <tr>
                                             <th>Expenses Date</th>
                                             <th>Other Expenses</th>
                                             <th>Narration</th>                                                                                         
                                         </tr>
                                     </thead>
                                     <tbody>
                                          
                                              <?php 
                                                 include "./db.php";
                                                 $sql="SELECT * from other ORDER BY other_id DESC LIMIT 0,1";
                                                 $result=$conn->query($sql);
                                                 if($row=$result->fetch_assoc()){
                                                     ?>
                                                        <tr>
                                                            <td><?php echo date("d-F-Y",strtotime($row['date'])) ?></td>
                                                            <td><?php echo $row['other_amount'] ?></td>
                                                            <td><?php echo $row['narration'] ?></td>
                                                        </tr>
                                                     <?php
                                                 }
                                              ?>
                                         
                                     </tbody>                                
                            </table>
                     </div>
                  </div>   
               </div>
           <!-- last record end-->
     </div>    
    <!-- dashboard end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>


</body>
</html>

 <?php 
    // php start
    if(isset($_POST["save"])){
        include "./db.php";       
       
        $expenses_date=$_POST["expenses_date"];
        $other_amount=$_POST["other_amount"];
        $narration=$_POST["narration"];
        $sql1="SELECT * FROM other WHERE date='$expenses_date' AND other_amount='$other_amount' AND narration='$narration'";
        $result1=$conn->query($sql1);
        if($row1=$result1->fetch_assoc()){
            // if record already exist
            ?>
<script>
    alertify.alert("<div class='text-warning'><i class='fa fa-exclamation-circle'></i> Sorry Expenses Already Added...";
</script>
             <?php
        }else{
            // if record already not exist
            $sql="INSERT INTO other(date,other_amount,narration)VALUES('$expenses_date','$other_amount','$narration')";
            $result=$conn->query($sql);
            if($result===TRUE){
                 ?>
    <script>    
        alertify.alert("<div class='text-success'><i class='fa fa-check-circle'></i> Other Expenses Saved</div>");
    </script>
                 <?php
            }else{
                ?>
    <script>
        alertify.alert("<div class='text-danger'>Oops... error Other Expenses not save</div>");
    </script>
                 <?php
            }
        }
}#else part of fetch_assoc()
       
 ?>