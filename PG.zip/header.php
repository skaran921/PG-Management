<!-- navbar -->
<nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top" >
           <a href="./dashboard.php" class="navbar-brand">
               <img src="./images/icon.png" alt="logo" style="border-radius:30px;width:40px;">
               PG Info
           </a>
          
           <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#myMenu">
               <span class="navbar-toggler-icon"></span>
           </button>

           <div class="collapse navbar-collapse" id="myMenu">
               <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a href="./addGuest.php" class="nav-link"> 
                            <span class="fa fa-plus"></span>
                            Add Guest
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="./viewGuest.php" class="nav-link"> 
                            <span class="fa fa-list-alt"></span>
                            View Guest's
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="./searchGuest.php" class="nav-link"> 
                            <span class="fa fa-search"></span>
                            Search Guest's
                        </a>
                    </li>

                    <!-- fee dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span class="fas fa-rupee-sign"></span> Fee's
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="./feeReceived.php"><span class="fas fa-rupee-sign"></span> Fee Received</a>
                        <a class="dropdown-item" href="./securityReceived.php"><span class="fas fa-rupee-sign"></span> Security Received</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </li>
                    <!-- fee dropdown -->


                     <!-- expanses dropdown -->
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span class="fas fa-rupee-sign"></span> Expenses
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="./electricityExpences.php"><span class="fas fa-rupee-sign"></span> Electricity Expenses</a>
                        <a class="dropdown-item" href="./foodExpenses.php"><span class="fas fa-rupee-sign"></span> Food Expenses</a>
                        <a class="dropdown-item" href="./otherExpenses.php"><span class="fas fa-rupee-sign"></span> Other Expenses</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="./electricityExpencesReport.php"><span class="fas fa-list-alt"></span> Electricity Expenses Report</a>
                        <a class="dropdown-item" href="./foodExpensesReport.php"><span class="fas fa-list-alt"></span> Food Expenses Report</a>
                        <a class="dropdown-item" href="./otherExpensesReport.php"><span class="fas fa-list-alt"></span> Other Expenses Report</a>
                      
                        </div>
                    </li>
                    <!-- fee dropdown -->

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span class="fa fa-file-invoice"></span> Rent Report's
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="./monthlyRentReport.php"> <i class='fa fa-calendar-alt'></i> Monthly Rent Report </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="./guestWiseRentReport.php"> <i class='fa fa-user-circle'></i> Guest Wise Rent Report </a>
                                                
                        </div>
                    </li>


                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span class="fa fa-cogs"></span> Settings
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#"> <i class='fa fa-lock'></i> Change Password</a>                        
                    </li>

                    <li class="nav-item">
                        <a href="javascript:void()" class="nav-link" onclick="logout()"> 
                            <span class="fa fa-sign-out-alt"></span>
                            Logout
                        </a>
                    </li>

               </ul>

               <div>
                   
               </div>
           </div>
      </nav>
  <!-- navbar end-->

<script>
   function logout(){
       alertify.confirm("Logout?",()=>{window.location.href='logout.php'})
   }
</script>

<style>
  .dialog>div {
    background-color: #111 !important;
    color: #fff;
    font-weight: 700;
    border-radius: 4px;
}

.dialog>div .ok {
    background-color: #26ae60 !important;
    color: #fff !important;
}

.dialog>div .ok:hover {
    background-color: #4CAF50 !important;
    color: #fff !important;
}

.dialog>div .cancel {
    background-color: #FF3031 !important;
    color: #fff !important;
}

.dialog>div .cancel :hover {
    background-color: #F00 !important;
    color: #fff !important;
}
</style>

<br>
<br>
<br>