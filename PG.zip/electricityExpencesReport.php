<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Electricity Expenses Report - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/feeReceived.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">

    <!-- data-tabel -->
     <link rel="stylesheet" type="text/css" href="css/bootstrap-table.min.css"/> 
     <style>
       td,th{
           text-align:center;
       }
    </style>
</head>
<body onload="getElectricityRecord()">
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
            <!-- main row start -->
        <div class="card" style="width:100% !important;margin-left:0px;">
              <div class="card-header">
                    <span class="fas fa-list-alt"></span> Electricity Report For <?php echo date("F Y");?>
                    <span style="float:right">
                         <span class="fa fa-print" onclick="window.print();"></span>
                    </span>
              </div>
              <!-- card-heading -->
              <div class="card-body">
                    <div class="mainRow" id="data">                     
                    </div>
                    <!-- main row end -->
              </div>
        </div>
            <!-- card end -->
    <!-- dashboard end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
<!-- popover min.js -->
<script src="./js/popper.min.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>



<script>
function getElectricityRecord(){ 
            $.ajax({url: "getElectricityRecord.php", success: function(result){
                        $("#data").html(result);
             }});
}
 
</script>
</body>
</html>

