<center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="600" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                          
                           <th>Date</th>
                           <th>Food Amount</th>
                           <th>Narration</th>                                           
                           <th>Action</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $month=date("m");
   $year=date("Y");
   $sql="SELECT * from food WHERE MONTH(date)='$month' AND YEAR(date)=$year ORDER BY food_id DESC";
   $result=$conn->query($sql);
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
             <td><?php echo date("d-m-Y",strtotime($row["date"]));?></td>
             <td><span class="fas fa-rupee-sign"></span> <?php echo $row["food_amount"];?>/-</td>
            <td><?php echo $row["narration"];?></td>
                       
            <td>
                <button class="btn btn-dark"><i class="fa fa-edit"></i></button>
                <button class="btn btn-dark"><i class="fa fa-trash"></i></button>
            </td>
         </tr>
       <?php 
   }
?>
                    </tbody>
               </table> 
           <center> 

<!-- bootstrap-table -->
<script type="text/javascript" src="js/bootstrap-table.min.js"></script>

<script>
function go(guest_id){
  window.open(`viewGuestRecord.php?guest_id=${guest_id}`)
}

</script>