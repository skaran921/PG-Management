<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Guest Record - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/viewGuestRecord.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->  
     <div class="container-fluid"> 
           <div class="card">
               <div class="card-header">
                   <span class="fa fa-eye"></span> Guest Detail's 
                   <span style="float:right" class="fa fa-print" onclick="window.print();"></span>                       
               </div>
                <!-- card hedaer end -->
               <div class="card-body">
  <!-- if guest id set  -->
  <?php 
      if(isset($_GET["guest_id"])){
          include "./db.php";
          $guest_id=$_GET["guest_id"];
          $sql="SELECT * FROM guest WHERE guest_id='$guest_id'";
         $result=$conn->query($sql);
          if($row=$result->fetch_assoc()){
            //   if record exist
            ?>
                 <div class="row">
                     <!-- guest_img -->
                     <div class="col-sm-3">                         
                                <img src="./upload/<?php echo date("Y/M",strtotime($row["cid"]))."/".$row["image"];?>"
                                class="img-fluid rounded-circle" style="width:90px;height:80px;cursor:pointer">   
                                <span>
                                  <!-- <b> Status:</b> -->
                                     <?php
                                        if($row["isNowStaying"]==="Yes"){
                                            ?>
                                               <i class="fa fa-circle text-success" style="font-size:20px;"></i>
                                            <?php 
                                        }else{
                                          ?>
                                             <i class="fa fa-circle text-danger" style="font-size:20px;"></i>
                                          <?php 
                                        }
                                     ?>                                      
                                </span>                                               
                        </div>
                     <!-- guest_id -->
                        <div class="col-sm-3">                         
                                    <label>Guest id:</label>
                                    <input type="text" value="<?php echo $row["guest_id"] ?>" style="max-width:80px;" readonly disabled>                                                  
                        </div>
                        <!-- guest_name -->
                        <div class="col-sm-3">                         
                                    <label>Guest Name:</label>
                                    <input type="text" value="<?php echo $row["guest_name"] ?>" readonly disabled>                                                  
                        </div>

                        <!-- guest_mobile no -->
                        <div class="col-sm-3">                         
                                    <label>Guest Mobile No.:</label>
                                    <input type="text" value="<?php echo $row["guest_mobile_no"] ?>" readonly disabled>                                                  
                        </div>

                        <!-- guest_father_name -->
                        <div class="col-sm-3">                         
                                    <label>Father Name:</label>
                                    <input type="text" value="<?php echo $row["father_name"] ?>" readonly disabled>                                                  
                        </div>

                         <!-- guest_father_mobile_no -->
                         <div class="col-sm-3">                         
                                    <label>Father Mobile No.:</label>
                                    <input type="text" value="<?php echo $row["father_mobile_no"] ?>" readonly disabled>                                                  
                        </div>

                         <!-- guest_father_mobile_no -->
                         <div class="col-sm-3">                         
                                    <label>Permanent Address:</label>
                                    <textarea readonly disabled><?php echo $row["permanent_address"] ?></textarea>                                              
                        </div>

                         <!-- company name -->
                         <div class="col-sm-3">                         
                                    <label> Comapany Name:</label>
                                    <input type="text" value="<?php echo $row["company_name"];?>" readonly disabled>                                            
                        </div>

                        <!-- Manager name -->
                        <div class="col-sm-3">                         
                                    <label> Manager Name:</label>
                                    <input type="text" value="<?php echo $row["manager_name"];?>" readonly disabled>                                            
                        </div>

                        <!-- manager mobile no -->
                        <div class="col-sm-3">                         
                                    <label> Manager Mobile Number:</label>
                                    <input type="text" value="<?php echo $row["manager_mobile_no"];?>" readonly disabled>                                            
                        </div>

                        <!-- period of stay -->
                        <div class="col-sm-3">                         
                                    <label> Period Of Stay :</label>
                                    <input type="text" value="<?php echo $row["period_of_stay"];?>" readonly disabled>                                            
                        </div>

                         <!-- purpose of stay -->
                         <div class="col-sm-3">                         
                                    <label> Purpose of Stay:</label>
                                    <input type="text" value="<?php echo $row["purpose_of_stay"];?>" readonly disabled>                                            
                        </div>

                         <!-- pre_period_of_stay -->
                         <div class="col-sm-3">                         
                                    <label> Pre Period Of Stay:</label>
                                    <input type="text" value="<?php echo $row["pre_period_of_stay"];?>" readonly disabled>                                            
                        </div>

                         <!-- pre_owner_name -->
                         <div class="col-sm-3">                         
                                    <label> Pre Owner Name:</label>
                                    <input type="text" value="<?php echo $row["pre_Owner_name"];?>" readonly disabled>                                            
                        </div>

                         <!-- pre_owner_mobile_no -->
                         <div class="col-sm-3">                         
                                    <label> Pre Owner Mobile No.:</label>
                                    <input type="text" value="<?php echo $row["pre_owner_mobile_no"];?>" readonly disabled>                                            
                        </div>

                         <!-- id_card_type  -->
                         <div class="col-sm-3">                         
                                    <label>ID Card Type :</label>
                                    <input type="text" value="<?php echo $row["id_card_type"];?>" readonly disabled>                                            
                        </div>

                         <!-- id card no -->
                         <div class="col-sm-3">                         
                                    <label> ID Card No.:</label>
                                    <input type="text" value="<?php echo $row["id_card_no"];?>" readonly disabled>                                            
                        </div>

                         <!-- rent_details -->
                         <div class="col-sm-3">                         
                                    <label> Rent Detail's:</label>
                                    <input type="text" value="<?php echo $row["rent_detail"];?>" readonly disabled>                                            
                        </div>

                         <!-- security_paid_amount -->
                         <div class="col-sm-3">                         
                                    <label> Security Paid Amount:</label>
                                    <input type="text" value="<?php echo $row["security_paid_amount"];?>" readonly disabled>                                            
                        </div>
                        <!-- security_Unpaid_amount -->
                        <div class="col-sm-3">                         
                                    <label> Security Unpaid Amount:</label>
                                    <input type="text" value="<?php echo $row["security_unpaid_amount"];?>" readonly disabled>                                            
                        </div>

                        <!-- key_no -->
                        <div class="col-sm-3">                         
                                    <label> Key No.:</label>
                                    <input type="text" value="<?php echo $row["key_no"];?>" readonly disabled>                                            
                        </div>

                         <!-- bed_no -->
                         <div class="col-sm-3">                         
                                    <label> Bed No.:</label>
                                    <input type="text" value="<?php echo $row["bed_no"];?>" readonly disabled>                                            
                        </div>

                         <!-- Remarks -->
                         <div class="col-sm-3">                         
                                    <label> Remarks:</label>
                                    <textarea readonly disabled><?php echo $row["remarks"];?></textarea>                                            
                        </div>

                        <!-- Remarks -->
                        <div class="col-sm-3">                         
                                    <label> Document:</label><br>
                                    <a href="upload/<?php echo date("Y/M",strtotime($row["cid"]))."/".$row["document"];?>" class="btn btn-light"><i class="fa fa-download"></i> Download</a>                                    
                        </div>

                        
                        <!--  -->
                        <div class="col-sm-3">                         
                                    <label> Entry Date:</label><br>
                                <?php echo date("d-m-Y h:i:s a",strtotime($row["cid"]));?>                                          
                        </div>
                  </div>   
              <!-- row end inside card-body  -->
            <?php 
          }else{
            //   if record not exist
                    echo "<center><h1 class='text-warning'>Record Not Found!!!</h1></center>";
          }
  ?>
                
 <?php
      }else{
        //   if guest id not set
        echo "<center><h1 class='text-danger'>Oops... Not a Correct Url</h1></center>";
      }
    //   end php script
 ?>             
               </div>
               <!-- card-body-end -->              
           </div>                       
     </div>    
    <!-- dashboard end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>

</body>
</html>

