<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Security Received - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/feeReceived.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
           <div class="card" style="width:40%;margin:auto;">
                  <div class="card-header" style="background-color:#00CCCD !important">
                        <span class="fas fa-rupee-sign"></span> Security Received
                  </div>
                  <!-- card-header -->
                  <div class="card-body"> 
                         <form action="" method="post">
                             <div class="form-group">
                                   <label> Select Guest Account:</label>
                                   <select name="guest_id" id="guest_id" required autofocus>
                                       <option value="">Select Guest Account</option>
                                         <?php  
                                           include "./db.php";
                                           $sql="SELECT guest_id,guest_name from guest WHERE isNowStaying='Yes'";
                                           $result=$conn->query($sql);
                                           while($row=$result->fetch_assoc()){
                                               ?>
                                                <option value="<?php echo $row['guest_id'];?>"><?php echo $row['guest_name']." (".$row['guest_id'].")";?></option>
                                               <?php 
                                           }
                                         ?>
                                   </select>

                                   <label>Security Amount:</label>
                                   <input type="number" name="security_amount" id="security_amount" placeholder="Secrity Received Amount" required>
                                   <button type="submit" style="background-color:#25CCF7" name="save" class="button" onclick="validate()"> <span class="fas fa-rupee-sign"></span> Received Security</button>
                                   <button type="reset" class="button reset_button"> <span class="fas fa-redo"></span> Reset Form</button>
                             </div>
                         </form>
                  </div>
                 <!-- card-body -->
           </div>
           <!-- card -->

           <!-- last record -->
               <div class="card" style="margin-top:10px;width:100%">
                     <div class="card-header" style="background-color:#2ecc71 !important">
                           <span class="fas fa-list-alt"></span> Last Entry Record
                     </div>
                     
                     <div class="card-body">
                         <div class="main_Table" style="overflow-x:auto">
                            <table  class="table table-bordered">                                
                                     <thead class="thead-light">
                                         <tr>
                                             <th>Date</th>
                                             <th>Guest_ID</th>
                                             <th>Guest_Name</th>
                                             <th>Security Amount</th>                                             
                                         </tr>
                                     </thead>
                                     <tbody>
                                          
                                              <?php 
                                                 include "./db.php";
                                                 $sql="SELECT *,guest.guest_name,guest.guest_id AS guestID FROM security LEFT JOIN guest ON guest.guest_id=security.guest_id ORDER BY security_id DESC LIMIT 0,1";
                                                 $result=$conn->query($sql);
                                                 if($row=$result->fetch_assoc()){
                                                     ?>
                                                        <tr>
                                                            <td><?php echo date("d-F-Y",strtotime($row['cid'])) ?></td>
                                                            <td><?php echo $row['guestID'] ?></td>
                                                            <td><?php echo $row['guest_name'] ?></td>
                                                            <td><?php echo "<i class='fas fa-rupee-sign'></i> ".$row['security_amount']."/-";?></td>
                                                                                                                   
                                                        </tr>
                                                     <?php
                                                 }
                                              ?>
                                         
                                     </tbody>                                
                            </table>
                     </div>
                  </div>   
               </div>
           <!-- last record end-->
     </div>    
    <!-- dashboard end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>

<!-- validate -->
<script>
   function validate(){
       let guest_id=document.querySelector("#guest_id").value;
       let security_amount=document.querySelector("#security_amount").value;
       if(guest_id===""){
           alertify.alert("<span class='fas fa-exclamation-triangle'></span> Please Select Guest Account !!!");
           return false;
       }else if(security_amount===""){
           alertify.alert("<span class='fas fa-exclamation-triangle'></span> Please Enter Security Amount !!!");
           return false;
       }
   }
</script>
<!-- validate end-->
</body>
</html>

 <?php 
    // php start
    if(isset($_POST["save"])){
        include "./db.php";
        $guest_id=$_POST["guest_id"];
        $security_amount=$_POST["security_amount"];
        $sql1="SELECT * FROM security WHERE guest_id='$guest_id'";
        $result1=$conn->query($sql1);
        if($row1=$result1->fetch_assoc()){
            // if record already exist
            ?>
<script>
    alertify.alert("<div class='text-warning'><i class='fa fa-exclamation-circle'></i> Sorry Security Already Received...");
</script>
             <?php
        }else{
            // if record already not exist
            $sql="INSERT INTO security(guest_id,security_amount)VALUES('$guest_id','$security_amount')";
            $result=$conn->query($sql);
            if($result===TRUE){
                 ?>
    <script>    
        alertify.alert("<div class='text-success'><i class='fa fa-check-circle'></i> Security Details Saved</div>");
    </script>
                 <?php
            }else{
                ?>
    <script>
        alertify.alert("<div class='text-danger'>Oops... error Security details not save</div>");
    </script>
                 <?php
            }
        }
}#else part of fetch_assoc()
       
 ?>