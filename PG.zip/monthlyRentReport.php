<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Monthly Rent Report - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/feeReceived.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">

    <!-- data-tabel -->
     <link rel="stylesheet" type="text/css" href="css/bootstrap-table.min.css"/> 
     
     <style>
       td,th{
           text-align:center;
       }
    </style>
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
            <!-- main row start -->
        <div class="card" style="width:100% !important;margin-left:0px;">
              <div class="card-header">
                    <span class="fas fa-calendar-alt"></span> Monthly Rent Report
                    <span style="float:right">
                         <span class="fa fa-print" onclick="window.print();"></span>
                    </span>
              </div>
              <!-- card-heading -->
              <div class="card-body">
                    <div class="mainRow" id="data"> 
                           <form action="" method="post" style="width:200px">
                                 <label>Select Month</label>
                                 <select name="month" id="month" required autofoucs>
                                     <option value="">Select Month</option>
                                     <option>January</option>
                                     <option>February</option>
                                     <option>March</option>
                                     <option>April</option>
                                     <option>May</option>
                                     <option>June</option>
                                     <option>July</option>
                                     <option>August</option>
                                     <option>September</option>
                                     <option>October</option>
                                     <option>November</option>
                                     <option>December</option>
                                 </select>
                                 <button class="button" name="go">Next</button>
                           </form>  

                           <?php
                            //   php start here
                                if(isset($_POST["go"])){
                                      ?>
                                        <center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="600" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Sr. No.</th>
                           <th>Guest_ID</th>
                           <th>Name</th>
                           <th>Mobile No.</th>
                           <th>Fee Amount</th>
                           <th>Fee Month</th>
                           <th>Fee Year</th>
                           <th>Fee Paid On  </th>
                           <th>Image</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $month=$_POST["month"];
   $year=date("Y");
   $sql="SELECT *,fees.guest_id AS fees_guest_id FROM fees
        left join guest ON guest.guest_id=fees.guest_id 
    WHERE fee_month='$month' AND fee_year='$year' ORDER BY fee_id DESC";
   $result=$conn->query($sql);
   $sr=1;
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
            <td><?php echo $sr;?></td>
            <td><?php echo $row["fees_guest_id"];?></td>
            <td><?php echo $row["guest_name"];?></td>
            <td><?php echo $row["guest_mobile_no"];?></td>           
            <td><?php echo $row["fee_amount"];?></td>           
            <td><?php echo $row["fee_month"];?></td>           
            <td><?php echo $row["fee_year"];?></td>           
            <td><?php echo date("d-M-Y h:i:s A",strtotime($row["cid"]));?></td>           
            <td><img src="./upload/<?php echo date("Y/M",strtotime($row["cid"]))."/".$row["image"];?>" class="img-fluid rounded-circle" style="width:60px;height:40px;cursor:pointer"></td>
         </tr>
       <?php 

       $sr++;
   }
?>
                    </tbody>
               </table> 
           </center> 


                                      <?php 
                                }#isset
                            // php end here
                           ?>            
                    </div>
                    <!-- main row end -->
              </div>
        </div>
            <!-- card end -->
    <!-- dashboard end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
<!-- popover min.js -->
<script src="./js/popper.min.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>
<!-- bootstrap-table -->
<script type="text/javascript" src="js/bootstrap-table.min.js"></script>
</body>
</html>

