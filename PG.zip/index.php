<?php 
  session_start();

  if(isset($_SESSION["pg_admin_id"])){
      header("Location:./dashboard.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
   
    <!-- external css -->
    <link rel="stylesheet" href="./css/index.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
       <!-- main div -->
         <div class="main">
                <center> 
                    <img src="./images/icon.png" alt="logo" class="icon">
                    <p class="heading">PG - Guest Information</p>
                </center>  
               <form id="form" action="" method="post">
                     <div class="form-group">
                        <input type="text" name="loginId" id="loginId" placeholder="User ID" required autofocus>   
                        <input type="password" name="password" id="password" placeholder="Password" required >   
                      </div>                      
                           <button type="submit" name="login" class="button">Login</button>
                      
               </form>
        </div>
       <!-- main div end-->


       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<!-- <script src="./js/bootstrap.min.js"></script> -->
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- php start here-->
   <?php 
      if(isset($_POST["login"])){
          $loginId=$_POST["loginId"];
          $password=$_POST["password"];
          include "db.php";
          $sql=$conn->prepare("SELECT admin_id FROM admin WHERE login_id=? AND pass=?");
          $sql->bind_param("ss",$loginId,$password);
          $sql->execute();
          $result=$sql->get_result();
          if($row=$result->fetch_assoc()){
                  $_SESSION["pg_admin_id"]=$row["admin_id"];
                  header("Location:./dashboard.php");
          }else{
                ?>
<script>
       alertify.alert("<div><center><div style='width:75px;height:70px;line-height:70px;border:none;background:#111;border-radius:50%'><b style='font-size:50px;color:#fff'>X</b></div></center></center><p class='text-danger font-weight-bold'>Opps... Sorry user id or password not matched!!!</p></div>")
</script>
                <?php
          }
          $sql->close();
      }
   ?>
<!-- php end here -->
</body>
</html>

