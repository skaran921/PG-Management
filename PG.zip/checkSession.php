<?php 
  session_start();

  if(isset($_SESSION["pg_admin_id"])){
  }else{
    header("Location:./index.php");
  }
?>