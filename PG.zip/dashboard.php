<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/dashboard.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
     include "./functions.php";
  ?>
 
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
            <!-- main row start -->
            <div class="row mainRow">
                <!-- col1 start -->
                  <div class="col-md-3 card">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-clock"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Time:</p>
                                    
                                    <p class="details">
                                        <p id="time"></p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col1 end here -->
 

                  <!-- col2 start -->
                  <div class="col-md-3 card">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fas fa-calendar"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Date:</p>
                                    
                                    <p class="details">
                                         <?php 
                                           echo date("D d-m-Y");
                                         ?>                                       
                                    </p>
                                                                      
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col2 end here -->

                  <!-- col3 start -->
                  <div class="col-md-3 card">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-user-secret"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Total Admin:</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalAdmin(); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col3 end here -->

                  <!-- col4 start -->
                  <div class="col-md-3 card">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-users"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Guest Counter:</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalGuest(); ?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col4 end here -->

                  <!-- col5 start -->
                  <div class="col-md-3 card">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fa fa-users"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Current Staying:</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getTotalGuestStayingNow();?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col5 end here -->

                  <!-- col6 start -->
                  <div class="col-md-3 card">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fas fa-rupee-sign"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Rent Due</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                            <?php echo getGuestRentDueToday();?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col6 end here -->


                  <!-- col7 start -->
                  <div class="col-md-3 card" onclick="window.location.href='./electricityExpencesReport.php'">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fas fa-bolt"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Electricity Expences</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                        <span class="fas fa-rupee-sign"></span>
                                         <?php echo getThisMonthElectricityExpenses();?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col7 end here -->

                  <!-- col7 start -->
                  <div class="col-md-3 card" onclick="window.location.href='./foodExpensesReport.php'">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">
                                  <span class="fas fa-hamburger"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Food Expences</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                        <span class="fas fa-rupee-sign"></span>
                                            <?php echo getThisMonthFoodExpenses();?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col7 end here -->

                 <!-- col8 start -->
                 <div class="col-md-3 card" onclick="window.location.href='./otherExpensesReport.php'">
                     <!-- row inside col start-->
                         <div class="row">
                              <div class="iconPart">                                  
                                  <span class="fas fa-money-bill-alt"></span>
                              </div>
                              <!-- col 1 -->    
                              <div class="textPart">
                                    <p class="heading"> Other Expences</p>
                                    
                                    <p class="details">
                                        <p id="time">
                                        <span class="fas fa-rupee-sign"></span>
                                            <?php echo getThisMonthOtherExpenses();?>
                                        </p>                                        
                                    </p>
                                  
                              </div>
                         </div>
                     <!-- row inside col end-->
                  </div>
                 <!-- col8 end here -->
                  
            </div>
            <!-- main row end -->
     </div>    
    <!-- dashboard end-->

    <!-- footer -->
      <?php include "./footer.php";?>
    <!-- footer end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>

<!-- clock script-->
<script>
      function clock(){
          let d=new Date();
          document.querySelector("#time").innerHTML=d.toLocaleTimeString();
      }
      setInterval(clock, 1000);
</script>
<!-- clock script end -->
</body>
</html>


