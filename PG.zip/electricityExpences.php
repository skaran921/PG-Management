<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Electricity Expenses - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/feeReceived.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
           <div class="card" style="width:40%;margin:auto;">
                  <div class="card-header" style="background-color:#1d1e22 !important">
                        <span class="fas fa-rupee-sign"></span> Electricity Expenses
                  </div>
                  <!-- card-header -->
                  <div class="card-body"> 
                         <form action="" method="post">
                             <div class="form-group">
                             <label> Select Electricity Month:</label>
                                   <select name="electricity_month" id="electricity_month" required>
                                       <option><?php echo date("F");?></option>
                                         <?php 
                                            for($m=1; $m<=12; $m++) {
                                                $month = date('F', mktime(0,0,0,$m, 1, date('Y')));
                                                echo "<option>".$month.'</option>';
                                                }
                                         ?>
                                   </select>
                                   <label>Security Amount:</label>
                                   <input type="number" name="electricity_amount" id="electricity_amount" placeholder="Electricity Paid Amount" required>                                            
                                   <button type="submit" style="background-color:#1d1e22" name="save" class="button" onclick="validate()"> <span class="fas fa-rupee-sign"></span> Save Electricity Expenses</button>
                                   <button type="reset" class="button reset_button"> <span class="fas fa-redo"></span> Reset Form</button>
                             </div>
                         </form>
                  </div>
                 <!-- card-body -->
           </div>
           <!-- card -->

           <!-- last record -->
               <div class="card" style="margin-top:10px;width:100%">
                     <div class="card-header" style="background-color:#2ecc71 !important">
                           <span class="fas fa-list-alt"></span> Last Entry Record
                     </div>
                     
                     <div class="card-body">
                         <div class="main_Table" style="overflow-x:auto">
                            <table  class="table table-bordered">                                
                                     <thead class="thead-light">
                                         <tr>
                                             <th>Date</th>
                                             <th>Electricity Expenses</th>
                                             <th>Electricity Bill Month</th>
                                             <th>Electricity Bill Year</th>                                             
                                         </tr>
                                     </thead>
                                     <tbody>
                                          
                                              <?php 
                                                 include "./db.php";
                                                 $sql="SELECT * from electricity  ORDER BY electricity_id DESC LIMIT 0,1";
                                                 $result=$conn->query($sql);
                                                 if($row=$result->fetch_assoc()){
                                                     ?>
                                                        <tr>
                                                            <td><?php echo date("d-F-Y",strtotime($row['cid'])) ?></td>
                                                            <td><?php echo $row['electricity_amount'] ?></td>
                                                            <td><?php echo $row['electricity_month'] ?></td>
                                                            <td><?php echo $row['electricity_year'] ?></td>
                                                                                                                   
                                                        </tr>
                                                     <?php
                                                 }
                                              ?>
                                         
                                     </tbody>                                
                            </table>
                     </div>
                  </div>   
               </div>
           <!-- last record end-->
     </div>    
    <!-- dashboard end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>

<!-- validate -->
<script>
   function validate(){
       let electricity_amount=document.querySelector("#electricity_amount").value;    
       if(electricity_amount===""){
           alertify.alert("<span class='fas fa-exclamation-triangle'></span> Please Enter Electricity Amount !!!");
           return false;
       }
   }
</script>
<!-- validate end-->
</body>
</html>

 <?php 
    // php start
    if(isset($_POST["save"])){
        include "./db.php";       
        $electricity_year=date("Y");
        $electricity_month=$_POST["electricity_month"];
        $electricity_amount=$_POST["electricity_amount"];
        $sql1="SELECT * FROM electricity WHERE electricity_amount='$electricity_amount' AND electricity_month='$electricity_month' AND electricity_year='$electricity_year'";
        $result1=$conn->query($sql1);
        if($row1=$result1->fetch_assoc()){
            // if record already exist
            ?>
<script>
    alertify.alert("<div class='text-warning'><i class='fa fa-exclamation-circle'></i> Sorry Electricity Expenses Already Added...");
</script>
             <?php
        }else{
            // if record already not exist
            $sql="INSERT INTO electricity(electricity_amount,electricity_month,electricity_year)VALUES('$electricity_amount','$electricity_month','$electricity_year')";
            $result=$conn->query($sql);
            if($result===TRUE){
                 ?>
    <script>    
        alertify.alert("<div class='text-success'><i class='fa fa-check-circle'></i> Electricity Expenses Saved</div>");
    </script>
                 <?php
            }else{
                ?>
    <script>
        alertify.alert("<div class='text-danger'>Oops... error Electricity Expenses not save</div>");
    </script>
                 <?php
            }
        }
}#else part of fetch_assoc()
       
 ?>