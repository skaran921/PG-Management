  <center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="600" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Sr. No.</th>
                           <th>ID</th>
                           <th>Name</th>
                           <th>Mobile No.</th>
                           <th>Father Name</th>
                           <th>Father Mobile No.</th>
                           <th>Permanent Address</th>
                           <th>Image</th>
                           <th>Action</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $sql="SELECT *  FROM  guest WHERE isNowStaying='Yes' ORDER BY guest_id DESC";
   $result=$conn->query($sql);
   $sr=1;
   while($row=$result->fetch_assoc()){
       ?>

         <tr>
            <td><?php echo $sr;?></td>
            <td><?php echo $row["guest_id"];?></td>
            <td><?php echo $row["guest_name"];?></td>
            <td><?php echo $row["guest_mobile_no"];?></td>
            <td><?php echo $row["father_name"];?></td>
            <td><?php echo $row["father_mobile_no"];?></td>
            <td><?php echo $row["permanent_address"];?></td>
            <td><img src="./upload/<?php echo date("Y/M",strtotime($row["cid"]))."/".$row["image"];?>" class="img-fluid rounded-circle" style="width:60px;height:40px;cursor:pointer"></td>
            <td>
                <button class="btn btn-dark" onclick="go(<?php echo $row['guest_id'];?>)"><i class="fa fa-eye"></i></button>
                <button class="btn btn-dark"><i class="fa fa-edit"></i></button>
                <button class="btn btn-dark"><i class="fa fa-times-circle"></i></button>
                <button class="btn btn-dark"><i class="fa fa-trash"></i></button>
                <button class="btn btn-dark"  onclick="goForRentDetails(<?php echo $row['guest_id'];?>)"><i class="fas fa-rupee-sign"></i></button>
            </td>
         </tr>
       <?php 

       $sr++;
   }
?>
                    </tbody>
               </table> 
           <center> 

<!-- bootstrap-table -->
<script type="text/javascript" src="js/bootstrap-table.min.js"></script>

<script>
function go(guest_id){
  window.open(`viewGuestRecord.php?guest_id=${guest_id}`)
}

function goForRentDetails(guest_id){
  window.open(`viewGuestRentRecord.php?guest_id=${guest_id}`)
}
</script>