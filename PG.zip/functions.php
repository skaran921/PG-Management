<!-- php functions -->
<?php 
function getTotalAdmin(){
    include "db.php";
    $sql="SELECT Count(*) as totalAdmin from admin";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["totalAdmin"];
    }
}
// end

function getTotalGuest(){
    include "db.php";
    $sql="SELECT Count(*) as totalAuest from guest";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["totalAuest"];
    }
}
// end


function getTotalGuestStayingNow(){
    include "db.php";
    $sql="SELECT Count(*) as totalguest from guest WHERE isNowStaying='Yes'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["totalguest"];
    }
}
// end

function getGuestSecurityPending(){
    include "db.php";
    $sql="SELECT Count(*) as totalguest from guest WHERE isNowStaying='Yes'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["totalguest"];
    }
}
// end

function getGuestRentDueToday(){
    include "db.php";
    $day=date("d");
    $sql="SELECT Count(*) as totalguest from guest WHERE isNowStaying='Yes' AND DAY(cid)='$day'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["totalguest"];
    }
}
// end

function getThisMonthElectricityExpenses(){
    include "db.php";
    $month=date("F");
    $sql="SELECT SUM(electricity_amount) as total from electricity WHERE  electricity_month='$month'";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getThisMonthFoodExpenses(){
    include "db.php";
    $month=date("m");
    $year=date("Y");
    $sql="SELECT SUM(food_amount) as total from food WHERE MONTH(date)='$month' AND YEAR(date)=$year";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

function getThisMonthOtherExpenses(){
    include "db.php";
    $month=date("m");
    $year=date("Y");
    $sql="SELECT SUM(other_amount) as total from other WHERE MONTH(date)='$month' AND YEAR(date)=$year";
    $result=$conn->query($sql);
    if($row=$result->fetch_assoc()){
        return $row["total"];
    }
}
// end

?>
<!-- php functions end-->