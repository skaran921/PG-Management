<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Guest Rent Record - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/viewGuestRecord.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->  
     <div class="container-fluid"> 
           <div class="card">
               <div class="card-header">
                   <span class="fa fa-eye"></span> Guest Rent Detail's 
                   <span style="float:right" class="fa fa-print" onclick="window.print();"></span>                       
               </div>
                <!-- card hedaer end -->
               <div class="card-body">
  <!-- if guest id set  -->
  <?php 
      if(isset($_GET["guest_id"])){
          include "./db.php";
          $guest_id=$_GET["guest_id"];
          $sql="SELECT * FROM  guest WHERE guest_id='$guest_id'";
         $result=$conn->query($sql);
          if($row=$result->fetch_assoc()){
            //   if record exist
            ?>
                 <div class="row">
                     <!-- guest_img -->
                     <div class="col-sm-3">                         
                                <img src="./upload/<?php echo date("Y/M",strtotime($row["cid"]))."/".$row["image"];?>"
                                class="img-fluid rounded-circle" style="width:90px;height:80px;cursor:pointer">   
                                <span>
                                  <!-- <b> Status:</b> -->
                                     <?php
                                        if($row["isNowStaying"]==="Yes"){
                                            ?>
                                               <i class="fa fa-circle text-success" style="font-size:20px;"></i>
                                            <?php 
                                        }else{
                                          ?>
                                             <i class="fa fa-circle text-danger" style="font-size:20px;"></i>
                                          <?php 
                                        }
                                     ?>                                      
                                </span>                                               
                        </div>
                     <!-- guest_id -->
                        <div class="col-sm-3">                         
                                    <label>Guest id:</label>
                                    <input type="text" value="<?php echo $row["guest_id"] ?>" style="max-width:80px;" readonly disabled>                                                  
                        </div>
                        <!-- guest_name -->
                        <div class="col-sm-3">                         
                                    <label>Guest Name:</label>
                                    <input type="text" value="<?php echo $row["guest_name"] ?>" readonly disabled>                                                  
                        </div>

                        <!-- guest_mobile no -->
                        <div class="col-sm-3">                         
                                    <label>Guest Mobile No.:</label>
                                    <input type="text" value="<?php echo $row["guest_mobile_no"] ?>" readonly disabled>                                                  
                        </div>

                         <!-- rent_details -->
                         <div class="col-sm-3">                         
                                    <label> Rent Detail's:</label>
                                    <input type="text" value="<?php echo $row["rent_detail"];?>" readonly disabled>                                            
                        </div>

                         <!-- security_paid_amount -->
                         <div class="col-sm-3">                         
                                    <label> Security Paid Amount:</label>
                                    <input type="text" value="<?php echo $row["security_paid_amount"];?>" readonly disabled>                                            
                        </div>
                        <!-- security_Unpaid_amount -->
                        <div class="col-sm-3">                         
                                    <label> Security Unpaid Amount:</label>
                                    <input type="text" value="<?php echo $row["security_unpaid_amount"];?>" readonly disabled>                                            
                        </div>

                       
                         <!-- bed_no -->
                         <div class="col-sm-3">                         
                                    <label> Bed No.:</label>
                                    <input type="text" value="<?php echo $row["bed_no"];?>" readonly disabled>                                            
                        </div>                        
                  </div>   
              <!-- row end inside card-body  -->
<hr>
            <?php 
          }else{
            //   if record not exist
                    echo "<center><h1 class='text-warning'>Record Not Found!!!</h1></center>";
          }
  ?>
                
 <?php
      }else{
        //   if guest id not set
        echo "<center><h1 class='text-danger'>Oops... Not a Correct Url</h1></center>";
      }
    //   end php script
 ?>             



              <!-- fee details -->
              <div class="card">
                           <div class="card-header">
                                <i class="fas fa-rupee-sign"></i> Rent Details
                           </div>
                                <!-- card-headersS -->
                           <div class="card-body">
                                <div class="main" style="overflow-x:auto">
                                        <table class="table table-bordered">
                                               <thead class="thead-light">
                                                 <tr>
                                                   <th>Date</th>
                                                   <th>Rent Month</th>
                                                   <th>Rent Year</th>
                                                   <th>Rent Amount</th>
                                                 </tr>  
                                                </thead>
                                                <tbody>
                                                <?php 
                                                  $guest_id=$_GET['guest_id'];
                                                 include "./db.php";
                                                 $sql="SELECT *,guest.rent_detail,guest.guest_id AS guestID,fees.cid as fee_cid FROM fees LEFT JOIN guest ON guest.guest_id=fees.guest_id WHERE fees.guest_id='$guest_id' ORDER BY fee_id DESC";                                              
                                                 $result=$conn->query($sql);
                                                 while($row=$result->fetch_assoc()){
                                                     ?>
                                                        <tr>
                                                            <td><?php echo date("d-F-Y",strtotime($row['fee_cid'])) ?></td>                                                                                                                 
                                                            <td><?php echo $row['fee_month'] ?></td>
                                                            <td><?php echo $row['fee_year'] ?></td>
                                                            <td><?php echo "<i class='fas fa-rupee-sign'></i> ".$row['fee_amount']."/-";?></td>
                                                            
                                                        </tr>
                                                     <?php
                                                 }
                                              ?>
                                                </tbody>
                                        </table>
                                </div>
                                <!-- responsive table -->
                           </div>
                           <!-- card-body -->
                       </div>
                       <!-- card-end -->
              <!-- fee details end-->


               <!-- security details -->
               <div class="card">
                           <div class="card-header">
                                <i class="fas fa-rupee-sign"></i> Security Details
                           </div>
                                <!-- card-headersS -->
                           <div class="card-body">
                                <div class="main" style="overflow-x:auto">
                                        <table class="table table-bordered">
                                               <thead class="thead-light">
                                                 <tr>
                                                   <th>Date</th>
                                                   <th>Security Paid Amount</th>
                                                   <th>Security Unpaid Amount</th>
                                                   <th>Security Received Amount</th>
                                                   <th>Balance</th>
                                                 </tr>  
                                                </thead>
                                                <tbody>
                                                <?php 
                                                  $guest_id=$_GET['guest_id'];
                                                  include "./db.php";
                                                  $sql="SELECT *,security.cid as security_cid ,security_paid_amount,security_unpaid_amount,guest.guest_id AS guestID FROM security LEFT JOIN guest ON guest.guest_id=security.guest_id WHERE security.guest_id='$guest_id' ORDER BY security_id ";
                                                  $result=$conn->query($sql);
                                                  if($row=$result->fetch_assoc()){
                                                      ?>
                                                         <tr>
                                                             <td><?php echo date("d-F-Y",strtotime($row['security_cid'])) ?></td>                         
                                                             <td><?php echo $row["security_paid_amount"];?></td>
                                                             <td><?php echo $row["security_unpaid_amount"];?></td>
                                                             <td>
                                                                 <?php echo "<i class='fas fa-rupee-sign'></i> ".$row['security_amount']."/-";?>
                                                             </td>
                                                                 <td>
                                                                     <b><i class='fas fa-rupee-sign'></i>
                                                                     <?php
                                                                      $balance = $row["security_unpaid_amount"] - $row["security_amount"];
                                                                      if($balance===0){
                                                                          echo "<span class='text-success'>NILL</span>";
                                                                      }else if($balance<0){
                                                                          echo "<span class='text-danger'>".$balance."</span>";                                                                          
                                                                      }else{
                                                                        echo "<span class='text-warning'>".$balance."</span>";
                                                                      }
                                                                    ?>
                                                                </b>
                                                            </td>                                                                                                                   
                                                         </tr>
                                                      <?php
                                                  }
                                              ?>
                                                </tbody>
                                        </table>
                                </div>
                                <!-- responsive table -->
                           </div>
                           <!-- card-body -->
                       </div>
                       <!-- card-end -->
              <!-- security details end-->


               </div>
               <!--main parent card-body-end -->              
           </div>                       
     </div>    
    <!-- dashboard end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>

</body>
</html>

