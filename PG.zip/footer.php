<div class="" style="width:100%;position:fixed;bottom:0;padding:13px;background:#f1f0ee;box-shadow:0px 1px 3px #999;">
      <div class="">
          <center>
              <b>
                   Designed And Develope By Karan Soni<br>
                   &copy;2019 v1.0
              </b>
        </center>
      </div>
</div>