<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Search Guest - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/searchGuest.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->

    <!-- dashboard start-->
     <div class="container-fluid"> 
         <div class="card">
              <div class="card-header">
                    <span class="fa fa-search"> Search Guest</span>
              </div>
            <!-- card-heading -->

            <div class="card-body">
                        <center>
                            <div class="searchBox">
                                <form action="" method="post" align="left">
                                    <div class="row">
                                          <div class="com-md-4">
                                                <label>Select Search By:</label>
                                                <select name="search_option" id="search_option" required>
                                                    <option value="guest_name">Guest Name</option>
                                                    <option value="guest_id">Guest ID</option>
                                                </select>
                                          </div>
                                          <!-- col1 end -->
                                          <div class="com-md-4">
                                                <label>Search Value:</label>
                                                <input type="text" placeholder="Enter Search Value" name="search_value" id="search_value" autofocus required>
                                                    
                                          </div>
                                          <!-- col2 end -->

                                          <div class="com-md-4">
                                                  <br>
                                                 <button type="submit" name="find" class="search_button">
                                                      <i class="fa fa-search"></i>
                                                 </button> 
                                          </div>
                                          <!-- col3 end -->
                                    </div>
                                    <!-- row end inside card -->                                                                        
                                </form>                                
                            </div>
                        </center>
                        <!-- form div end -->
                        <div id="data">    
                        <?php 
   if(isset($_POST["search_option"]) && isset($_POST["search_value"]) && isset($_POST["find"]) ){
?>
<center> 
               <table 
                      id="myTable" 
                      class="table table-striped table-sm"  
                      data-toggle="table"
                      data-pagination="true"
                      data-search="true"
                      data-height="600" 
                      data-sortable="true"  
                      data-show-refresh="true",
                      data-show-toggle="true",
                      data-show-fullscreen="true",
                      data-smart-display="true",
                      data-show-columns="true"                                

               >
               
                    <thead class="thead-dark">
                       <tr>
                           <th>Sr. No.</th>
                           <th>ID</th>
                           <th>Name</th>
                           <th>Mobile No.</th>
                           <th>Father Name</th>
                           <th>Father Mobile No.</th>
                           <th>Permanent Address</th>
                           <th>Image</th>
                           <th>Action</th>
                       </tr>
                    </thead>
                    <tbody>                     
                    <?php 
   include "./db.php";
   $search_option=$_POST["search_option"];
   $search_value=$_POST["search_value"];
   $sql="SELECT *  FROM  guest WHERE $search_option LIKE '%$search_value%' ORDER BY guest_id DESC";
   $result=$conn->query($sql);
   $sr=1;
   $isRecord=false;
   while($row=$result->fetch_assoc()){
            $isRecord=true;
       ?>
         <tr>
            <td><?php echo $sr;?></td>
            <td><?php echo $row["guest_id"];?></td>
            <td><?php echo $row["guest_name"];?></td>
            <td><?php echo $row["guest_mobile_no"];?></td>
            <td><?php echo $row["father_name"];?></td>
            <td><?php echo $row["father_mobile_no"];?></td>
            <td><?php echo $row["permanent_address"];?></td>
            <td><img src="./upload/<?php echo date("Y/M",strtotime($row["cid"]))."/".$row["image"];?>" class="img-fluid rounded-circle" style="width:60px;height:40px;cursor:pointer"></td>
            <td>
                <button class="btn btn-dark" onclick="go(<?php echo $row['guest_id'];?>)"><i class="fa fa-eye"></i></button>
                <button class="btn btn-dark"><i class="fa fa-edit"></i></button>
                <button class="btn btn-dark"><i class="fa fa-times-circle"></i></button>
                <button class="btn btn-dark"><i class="fa fa-trash"></i></button>
            </td>
         </tr>
       <?php 

       $sr++;       
   }#while end

   if(!$isRecord){
        echo "<tr><th colspan='9' class='text-center text-danger display-4 p-4'>Sorry No Record Found!!!</th></tr>";
   }
   
?>
                    </tbody>
               </table> 
           <center> 
 <?php  
   }
//    isset end
?>
<!-- bootstrap-table -->
<script type="text/javascript" src="js/bootstrap-table.min.js"></script>

<script>
function go(guest_id){
  window.open(`viewGuestRecord.php?guest_id=${guest_id}`)
}
</script>      
                        </div>
                        <!-- main row end -->
            </div>
            <!-- card-body-end  -->
         </div>
      <!-- card -->
     </div>    
    <!-- dashboard end-->
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>


</body>
</html>

