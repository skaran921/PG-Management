<?php 
   include "./checkSession.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="skran921, Karan Soni">
    <meta name="description" keyword="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="description" content="Saini PG Zirakpur,PG in Baltana,PG in Zirakpur, Saini PG">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Guest - Saini PG</title>
    <!-- bootstrap -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <!-- themify -->
    <link rel="stylesheet" href="./fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="./fontawesome/css/brand.css">
    <link rel="stylesheet" href="./fontawesome/css/solid.css">
    <!-- external css -->
    <link rel="stylesheet" href="./css/addGuest.css">
    <!-- alertify -->
    <link rel="stylesheet" href="./alertify/css/alertify.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/icon.png" type="image/x-icon">
</head>
<body>
  <!-- header-->
  <?php 
     include "./header.php";
  ?>
  <!-- header -->
  
  <!-- form -->
     <div class="container">
          <div class="card">
              <div class="card-heading">
                  <span class="fa fa-plus"></span>
                  Add Guest Information
              </div>
              <!-- card-heading -->

              <!-- card-body -->
              <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                <!-- maoin row -->
                        <div class="row">
                            <!-- col1 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Name:</label><br>
                                      <input type="text" name="guest_name" id="guest_name" placeholder="Guest Full Name" required autofocus> 
                                  </div>
                            </div>
                            <!-- col1 end here -->

                             <!-- col2 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Mobile No.:</label><br>
                                      <input type="number" name="guest_mobile_no" id="guest_mobile_no" placeholder="Guest Mobile No." required> 
                                  </div>
                            </div>
                            <!-- col2 end here -->

                             <!-- col3 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Father Name:</label><br>
                                      <input type="text" name="father_name" id="father_name" placeholder="Guest Father/Spouse Name" required> 
                                  </div>
                            </div>
                            <!-- col3 end here -->

                            <!-- col4 start here -->
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Father/Spouse Mobile No:</label><br>
                                      <input type="number" name="father_mobile_no" id="father_mobile_no" placeholder="Guest Father/Spouse Mobile No." required> 
                                  </div>
                            </div>
                            <!-- col4 end here -->

                             <!-- col5 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Permanent Address:</label><br>
                                      <textarea name="permanent_address" id="permanent_address" placeholder="Guest Permanent Address" required> </textarea>
                                  </div>
                            </div>
                            <!-- col5 end here -->

                             <!-- col6 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Company Name:</label><br>
                                      <input type="text" name="company_name" id="company_name" placeholder="Guest Company Name" required> 
                                  </div>
                            </div>
                            <!-- col6 end here -->

                             <!-- col7 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Manager Name:</label><br>
                                      <input type="text" name="manager_name" id="manager_name" placeholder="Guest Company Manager Name" required> 
                                  </div>
                            </div>
                            <!-- col7 end here -->

                             <!-- col7 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Maanger Mobile No.:</label><br>
                                      <input type="text" name="manager_mobile_number" id="manager_mobile_number" placeholder="Manager Mobile Number" required> 
                                  </div>
                            </div>
                            <!-- col7 end here -->

                            
                             <!-- col8 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Period of Stay:</label><br>
                                      <input type="text" name="period_of_stay" id="period_of_stay" placeholder="Period Of Stay eg. 15days, 1 month" required> 
                                  </div>
                            </div>
                            <!-- col8 end here -->

                             <!-- col9 start here -->
                             <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Purpose of Stay:</label><br>
                                      <input type="text" name="purpose_of_stay" id="purpose_of_stay" placeholder="Purpose Of Stay" required> 
                                  </div>
                            </div>
                            <!-- col9 end here -->
                            <hr>

                            <!-- col9 start here -->
                           <div class="col-sm-12"><p><b> <hr>Previous Stay info (if any)</b></p></div> 
                            <div class="col-sm-6">
                                  <div class="form-group">
                                      <label><i class="fas fa-hand-o-left"></i> Period of Stay:</label><br>
                                      <input type="text" name="pre_period_of_stay" id="pre_period_of_stay" placeholder="Period Of Stay eg. 15days, 1 month" required> 
                                  </div>
                            </div>
                            <!-- col9 end here -->

                         <!-- col10 start here -->
                         <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Owner Name:</label><br>
                                      <input type="text" name="pre_owner_name" id="pre_owner_name" placeholder="Owner Name" required> 
                                  </div>
                            </div>
                        <!-- col10 end here -->

                         <!-- col10 start here -->
                         <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Owner Mobile Number:</label><br>
                                      <input type="number" name="pre_owner_mobile_no" id="pre_owner_mobile_no" placeholder="Owner Mobile Number" required> 
                                  </div>
                            </div>
                        <!-- col10 end here -->

                         <div class="col-sm-12"><p><b> <hr>ID Proof Details</b></p></div> 

                          <!-- col11 start here -->
                          <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Select ID Card Type:</label><br>
                                      <select type="number" name="id_card_type" id="id_card_type" required> 
                                            <option value="">Select ID Card Type</option>
                                            <option>Aadhar Card</option>
                                            <option>Voter Card</option>
                                            <option>Passport</option>
                                            <option>Driving Licence</option>
                                            <option>Pan Card</option>
                                      </select>
                                  </div>
                            </div>
                        <!-- col11 end here -->

                          <!-- col12 start here -->
                          <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>ID Card Number:</label><br>
                                      <input type="text" name="id_card_no" id="id_card_no" placeholder="ID Card No" required> 
                                  </div>
                            </div>
                        <!-- col12 end here -->

                        
                          <!-- col13 start here -->
                          <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Rent Detail:</label><br>
                                      <input type="number" name="rent_detail" id="rent_detail" placeholder="Rent Detail" required> 
                                  </div>
                           </div>
                        <!-- col13 end here -->

                         <!-- col14 start here -->
                         <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Security Paid Amount:</label><br>
                                      <input type="number" name="security_paid_amount" id="security_paid_amount" placeholder="Security Paid Amount" required> 
                                  </div>
                           </div>
                        <!-- col14 end here -->

                         <!-- col15 start here -->
                         <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Security Unpaid Paid Amount:</label><br>
                                      <input type="number" name="security_unpaid_amount" id="security_unpaid_amount" placeholder="Security Unpaid Amount" value="0" required> 
                                  </div>
                           </div>
                        <!-- col15 end here -->

                         <!-- col15 start here -->
                         <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Key No.:</label><br>
                                      <input type="number" name="key_no" id="key_no" placeholder="Key Number"> 
                                  </div>
                           </div>
                        <!-- col15 end here -->

                          

                        <!-- col15 start here -->
                        <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Bed/Room No.:</label><br>
                                      <input type="number" name="bed_no" id="bed_no" placeholder="Bed OR Room No."  required> 
                                  </div>
                           </div>
                        <!-- col15 end here -->


                        
                         <!-- col15 start here -->
                         <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Remarks:</label><br>
                                      <textarea name="remarks" id="Remarks" placeholder="Remarks"> </textarea>
                                  </div>
                           </div>
                        <!-- col15 end here -->

                      
                          <!-- col16 start here -->
                          <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Select Image:</label><br>
                                      <input type="file" name="image" accept="image/*" id="image" required>                                       
                                  </div>
                           </div>
                        <!-- col16 end here -->

                         <!-- col16 start here -->
                         <div class="col-sm-6">
                                  <div class="form-group">
                                      <label>Select ID Proof:</label><br>
                                      <input type="file" name="document" id="document" accept="application/pdf" required> 
                                  </div>
                           </div>
                        <!-- col16 end here -->
                        <!-- col 17 start -->
                        <div class="col-sm-12">
                                <center>
                                    <button type="submit" name="save" class="button saveBtn">Save Guest Info</button>
                                    <button type="reset" class="button resetBtn">Reset Form</button>
                                </center>
                        </div>
                        <!-- col 17 end here-->
                    </div> 
                    <!-- main row end here -->
                    </form>
              </div>
          </div>
     </div>
  <!-- form end-->
<br>
<br>
<br>
       <!-- jquery.js -->
<script src="./js/jquery.js"></script>
       <!-- bootstrap min.js -->
<script src="./js/bootstrap.min.js"></script>
<!-- alertify -->
<script src="./alertify/js/alertify.js"></script>
<!-- fontawsome -->
<script src="./fontawesome/js/fontawesome.min.js"></script>
<!-- main script goes here -->
      <?php
         if(isset($_POST["save"])){
             $guest_name=$_POST["guest_name"];
             $guest_mobile_no=$_POST["guest_mobile_no"];
             $father_name=$_POST["father_name"];
             $father_mobile_no=$_POST["father_mobile_no"];
             $permanent_address=$_POST["permanent_address"];
             $company_name=$_POST["company_name"];
             $manager_name=$_POST["manager_name"];
             $manager_mobile_no=$_POST["manager_mobile_number"];
             $period_of_stay=$_POST["period_of_stay"];
             $purpose_of_stay=$_POST["purpose_of_stay"];
             $pre_period_of_stay=$_POST["pre_period_of_stay"];
             $pre_owner_name=$_POST["pre_owner_name"];
             $pre_owner_mobile_no=$_POST["pre_owner_mobile_no"];
             $id_card_type=$_POST["id_card_type"];    
             $id_card_no=$_POST["id_card_no"];
             $rent_detail=$_POST["rent_detail"];
             $security_paid_amount=$_POST["security_paid_amount"];
             $security_unpaid_amount=$_POST["security_unpaid_amount"];
             $key_no=$_POST["key_no"];
             $bed_no=$_POST["bed_no"];
             $remarks=$_POST["remarks"];
             $image=$_FILES["image"]["name"];
             $imageName=$guest_mobile_no.".png";
             $year=date("Y");
             $month=date("M");
             $document=$_FILES["document"]["name"];
             $documentName=$guest_mobile_no.".pdf";
             include "./db.php";
             $sql1="SELECT guest_id FROM guest WHERE guest_name='$guest_name' AND guest_mobile_no='$guest_mobile_no' AND father_name='$father_name'";
             $sql="INSERT INTO guest(guest_name, guest_mobile_no, father_name, father_mobile_no, permanent_address, company_name,
              manager_name, manager_mobile_no, period_of_stay, purpose_of_stay, pre_period_of_stay, pre_Owner_name, pre_owner_mobile_no,
               id_card_type, id_card_no, rent_detail, security_paid_amount, security_unpaid_amount,key_no,bed_no,remarks,image,document)
               VALUES('$guest_name','$guest_mobile_no','$father_name','$father_mobile_no','$permanent_address','$company_name',
               '$manager_name','$manager_mobile_no','$period_of_stay','$purpose_of_stay','$pre_period_of_stay','$pre_owner_name','$pre_owner_mobile_no',
               '$id_card_type','$id_card_no','$rent_detail','$security_paid_amount','$security_unpaid_amount','$key_no','$bed_no','$remarks','$imageName','$documentName')";
            $result1=$conn->query($sql1);
            // if record found
            if($row1=$result1->fetch_assoc()){
                  ?>
<script>
    alertify.alert("<p style='fontSize:20px;color:#f00;'>Ooops...Record Already Exist...</p>")
</script>
                  <?php 
            }else{
                // if record not exist               
                   if(file_exists("upload/$year/$month")){                         
                   }else{
                     mkdir("upload/$year/$month",0777,true);        
                   }
                if(
                    move_uploaded_file($_FILES["image"]["tmp_name"],"upload/$year/$month/$imageName") && 
                    move_uploaded_file($_FILES["document"]["tmp_name"],"upload/$year/$month/$documentName")
                  ){
                        $result=$conn->query($sql);
                        if($result===TRUE){
                            // if data store into db
                            ?>
<script>
       alertify.alert("<div class='bg-success p-4 text-light'><center><i class='fa fa-check-circle'></i> Guest Information Saved!!!</center></i></div>");
</script>
                            <?php
                        }else{
                            // if data not store in DB
                            ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light'><center><i class='fa fa-times-circle'></i> Error... Guest Information Not Saved!!!</center></i></div>");
</script>
 <?php
                        }
                }else{
                    // if files not uploaded
                    ?>
<script>
        alertify.alert("<div class='bg-danger p-4 text-light' style='font-size:18px'><center><p><i class='fas fa-times-circle' style='font-size:50px;'></i></p>Oops... Image OR ID Proff Not Uploaded!!!</center></i></div>");      
</script>
                    <?php 
                }
            }
         }#isset
      ?>
<!-- main script end here -->
</body>
</html>

