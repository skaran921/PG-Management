-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2019 at 07:31 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pg`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `first_name` varchar(70) NOT NULL,
  `last_name` varchar(70) NOT NULL,
  `login_id` varchar(70) NOT NULL,
  `pass` varchar(70) NOT NULL,
  `cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(30) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `first_name`, `last_name`, `login_id`, `pass`, `cid`, `uid`, `status`) VALUES
(1, 'Karan', 'Soni', '0007', 'skaran921', '2019-04-07 09:56:35', '2019-04-07 09:56:35', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `electricity`
--

CREATE TABLE `electricity` (
  `electricity_id` int(11) NOT NULL,
  `electricity_amount` int(11) NOT NULL,
  `electricity_month` mediumtext NOT NULL,
  `electricity_year` year(4) NOT NULL,
  `cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `electricity`
--

INSERT INTO `electricity` (`electricity_id`, `electricity_amount`, `electricity_month`, `electricity_year`, `cid`, `uid`) VALUES
(1, 4000, 'April', 2019, '2019-04-19 12:14:21', '2019-04-19 12:14:21');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `fee_id` int(11) NOT NULL,
  `guest_id` int(11) NOT NULL,
  `fee_month` varchar(30) NOT NULL,
  `fee_year` varchar(30) NOT NULL,
  `fee_amount` int(11) NOT NULL,
  `cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`fee_id`, `guest_id`, `fee_month`, `fee_year`, `fee_amount`, `cid`, `uid`) VALUES
(10, 5, 'April', '2019', 5500, '2019-04-19 09:40:41', '2019-04-19 09:40:41'),
(11, 5, 'January', '2019', 5500, '2019-04-19 10:48:32', '2019-04-19 10:48:32'),
(12, 3, 'April', '2019', 1000, '2019-04-19 10:58:13', '2019-04-19 10:58:13');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `food_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `food_amount` int(11) NOT NULL,
  `narration` text NOT NULL,
  `cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`food_id`, `date`, `food_amount`, `narration`, `cid`, `uid`) VALUES
(1, '2019-04-19', 500, 'Regarding Vegitable Oil', '2019-04-19 14:42:48', '2019-04-19 14:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `guest_id` int(11) NOT NULL,
  `guest_name` varchar(100) NOT NULL,
  `guest_mobile_no` varchar(15) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `father_mobile_no` varchar(15) NOT NULL,
  `permanent_address` text,
  `company_name` varchar(100) NOT NULL DEFAULT 'Not Applicable',
  `manager_name` varchar(100) NOT NULL DEFAULT 'Not Applicable',
  `manager_mobile_no` varchar(15) NOT NULL DEFAULT 'Not Applicable',
  `period_of_stay` varchar(30) NOT NULL,
  `purpose_of_stay` varchar(80) NOT NULL,
  `pre_period_of_stay` varchar(100) NOT NULL DEFAULT 'Not Applicable',
  `pre_Owner_name` varchar(80) NOT NULL DEFAULT 'Not Applicable',
  `pre_owner_mobile_no` varchar(15) NOT NULL DEFAULT 'Not Applicable',
  `id_card_type` varchar(80) NOT NULL,
  `id_card_no` varchar(60) NOT NULL,
  `rent_detail` int(11) NOT NULL,
  `security_paid_amount` int(11) NOT NULL,
  `security_unpaid_amount` int(11) NOT NULL,
  `key_no` varchar(20) NOT NULL DEFAULT 'N/A',
  `bed_no` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Active',
  `isNowStaying` varchar(20) NOT NULL DEFAULT 'Yes',
  `cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `image` text NOT NULL,
  `document` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`guest_id`, `guest_name`, `guest_mobile_no`, `father_name`, `father_mobile_no`, `permanent_address`, `company_name`, `manager_name`, `manager_mobile_no`, `period_of_stay`, `purpose_of_stay`, `pre_period_of_stay`, `pre_Owner_name`, `pre_owner_mobile_no`, `id_card_type`, `id_card_no`, `rent_detail`, `security_paid_amount`, `security_unpaid_amount`, `key_no`, `bed_no`, `remarks`, `status`, `isNowStaying`, `cid`, `uid`, `image`, `document`) VALUES
(3, 'demo', '9874563214', 'demo', '68764646', 'demo ', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', 'demo', '09908033', 'Aadhar Card', '499798798', 10000, 1000, 10, '10', 0, '0', 'Active', 'Yes', '2019-04-11 17:20:50', '2019-04-11 17:20:50', '9874563214.png', '9874563214.pdf'),
(5, 'Karan Soni', '9466067763', 'Brij Lal', '9416587160', 'NEAR Judicail court sirsa road dhani lakhji ellenabad', 'integratio pvt ltd', 'Gagan Sharma', '9896831507', '6 Months', 'Training', 'N/A', 'N/A', '0', 'Aadhar Card', '5603434233', 5500, 0, 1000, '46', 307, ' ', 'Active', 'Yes', '2019-04-18 15:43:24', '2019-04-19 11:21:53', '9466067763.png', '9466067763.pdf'),
(6, 'abc', '9815515151', 'cvs', '984565333', ' abcdef', 'xxx', 'mr m', '985858585', '10 day', '10 day', 'coming from home town', 'father', '585858', 'Aadhar Card', '8585858585858', 1000, 0, 0, '541', 101, ' asnhbg', 'Active', 'Yes', '2019-04-25 14:24:16', '2019-04-25 14:24:16', '9815515151.png', '9815515151.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `other`
--

CREATE TABLE `other` (
  `other_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `other_amount` int(11) NOT NULL,
  `narration` text NOT NULL,
  `cid` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `other`
--

INSERT INTO `other` (`other_id`, `date`, `other_amount`, `narration`, `cid`, `uid`) VALUES
(1, '2019-04-20', 1000, 'other expenses', '2019-04-20 02:27:53', '2019-04-20 02:27:53'),
(2, '2019-04-20', 1000, 'another other expenses', '2019-04-20 02:28:21', '2019-04-20 02:28:21'),
(3, '2019-04-20', 200, 'other expenses', '2019-04-20 02:28:58', '2019-04-20 02:28:58'),
(4, '2019-04-20', 300, 'expenses', '2019-04-20 02:31:20', '2019-04-20 02:31:20'),
(5, '2019-04-20', 100, 'expensess', '2019-04-20 02:32:47', '2019-04-20 02:32:47'),
(6, '2019-04-20', 150, 'paid', '2019-04-20 02:33:42', '2019-04-20 02:33:42');

-- --------------------------------------------------------

--
-- Table structure for table `security`
--

CREATE TABLE `security` (
  `security_id` int(11) NOT NULL,
  `guest_id` int(11) NOT NULL,
  `security_amount` int(11) NOT NULL,
  `cid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `security`
--

INSERT INTO `security` (`security_id`, `guest_id`, `security_amount`, `cid`, `uid`) VALUES
(1, 5, 1000, '2019-04-19 10:05:49', '2019-04-19 10:05:49'),
(2, 3, 1000, '2019-04-19 10:06:06', '2019-04-19 10:06:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `electricity`
--
ALTER TABLE `electricity`
  ADD PRIMARY KEY (`electricity_id`);

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`fee_id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`guest_id`);

--
-- Indexes for table `other`
--
ALTER TABLE `other`
  ADD PRIMARY KEY (`other_id`);

--
-- Indexes for table `security`
--
ALTER TABLE `security`
  ADD PRIMARY KEY (`security_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `electricity`
--
ALTER TABLE `electricity`
  MODIFY `electricity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `fees`
--
ALTER TABLE `fees`
  MODIFY `fee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `guest`
--
ALTER TABLE `guest`
  MODIFY `guest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `other`
--
ALTER TABLE `other`
  MODIFY `other_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `security`
--
ALTER TABLE `security`
  MODIFY `security_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
